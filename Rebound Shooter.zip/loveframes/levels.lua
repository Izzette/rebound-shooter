levels = {}

levels.levelA = {
 {t=02, x=400, y = 0, c=true, typeE = "square"},
 {t=10, x=200, y = 0, c=true, typeE = "square"}, 
 {t=10, x=550, y = 0, c=true, typeE = "square"}, 
 {t=10, x=400, y = 0, c=true, typeE = "mine"}, 
 {t=10, x=400, y = 0, c=true, typeE = "mach"}
 }
levels.levelB = {
 {t=2, x=400, y = 0, c=true, typeE = "mach"}, 
 {t=5, x=100, y = 0, c=true, typeE = "square"}, 
 {t=5, x=200, y = 0, c=true, typeE = "square"}, 
 {t=5, x=300, y = 0, c=true, typeE = "square"}, 
 {t=5, x=400, y = 0, c=true, typeE = "square"},
 {t=5, x=500, y = 0, c=true, typeE = "square"},
 {t=5, x=600, y = 0, c=true, typeE = "square"},
 {t=5, x=700, y = 0, c=true, typeE = "square"},
 {t=9, x=100, y = 0, c=true, typeE = "mine"}, 
 {t=9, x=200, y = 0, c=true, typeE = "mine"}, 
 {t=9, x=300, y = 0, c=true, typeE = "mine"}, 
 {t=9, x=400, y = 0, c=true, typeE = "mine"},
 {t=9, x=500, y = 0, c=true, typeE = "mine"},
 {t=9, x=600, y = 0, c=true, typeE = "mine"},
 {t=9, x=700, y = 0, c=true, typeE = "mine"}
}
levels.levelC = {
 {t=2, x=250, y = 0, c=true, typeE = "square"}, 
 {t=2, x=400, y = 0, c=true, typeE = "square"},
 {t=2, x=550, y = 0, c=true, typeE = "square"},
 {t=6, x=250, y = 0, c=true, typeE = "mach"}, 
 {t=6, x=400, y = 0, c=true, typeE = "mach"}, 
 {t=6, x=550, y = 0, c=true, typeE = "mach"},
 {t=10, x=250, y = 0, c=true, typeE = "mine"}, 
 {t=10, x=400, y = 0, c=true, typeE = "mine"}, 
 {t=10, x=550, y = 0, c=true, typeE = "mine"}, 
 {t=14, x=250, y = 0, c=true, typeE = "square"},
 {t=14, x=400, y = 0, c=true, typeE = "mine"},
 {t=14, x=550, y = 0, c=true, typeE = "mach"}
}